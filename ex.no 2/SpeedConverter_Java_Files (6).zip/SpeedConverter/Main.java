import java.util.Scanner;
import converter.Speed;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Speed s = new Speed();

        System.out.println("1. km/h to m/s");
        System.out.println("2. m/s to km/h");
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();

        System.out.print("Enter speed: ");
        double speed = sc.nextDouble();

        if (choice == 1) {
            System.out.println("Speed = " + s.kmphToMps(speed) + " m/s");
        } else if (choice == 2) {
            System.out.println("Speed = " + s.mpsToKmph(speed) + " km/h");
        } else {
            System.out.println("Invalid choice");
        }

        sc.close();
    }
}
