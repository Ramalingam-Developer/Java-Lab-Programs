package converter;

public class Speed {
    public double kmphToMps(double speed) {
        return speed * 5 / 18;
    }

    public double mpsToKmph(double speed) {
        return speed * 18 / 5;
    }
}
